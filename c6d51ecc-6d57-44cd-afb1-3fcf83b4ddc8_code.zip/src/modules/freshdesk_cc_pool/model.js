
// const Ticket = koneksi.define('tickets', {
//     // Model attributes are defined here
//     id: {
//       type: DataTypes.STRING,
//         primaryKey: true
//       },
//       "ticket_id" :  {
//         type: DataTypes.STRING
//       },
//     "cc_email" :  {
//         type: DataTypes.STRING
//       },
//   }, {
//     // Other model options go here
//     freezeTableName: true,
//     paranoid:true,
//     deletedAt: 'deleted'
//   });