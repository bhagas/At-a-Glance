// import db from '../../config/koneksi.js'
// import model from './model';




