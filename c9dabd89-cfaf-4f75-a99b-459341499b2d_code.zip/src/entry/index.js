
// module.exports = require('./entry')
export default await import('./entry.js')