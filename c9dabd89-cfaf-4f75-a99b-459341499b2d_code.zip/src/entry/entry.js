import 'dotenv/config'
import  express from 'express';
import { ApolloServer } from'@apollo/server';
import { expressMiddleware } from'@apollo/server/express4';
import { ApolloServerPluginDrainHttpServer }from'@apollo/server/plugin/drainHttpServer';
import graphqlUploadExpress from 'graphql-upload/graphqlUploadExpress.mjs';
import { ApolloServerPluginLandingPageDisabled }  from'@apollo/server/plugin/disabled';
import log_model from '../modules/log/model.js';
import path from'path';
import http from'http';
import cors from'cors';
import { v4 as uuidv4 } from 'uuid';
import bodyParser from'body-parser';
const app = express()
import jwt from'../helper/jwt.js'
import router  from'../router.js'
import schema from '../config/graphqlmerge.js';
import { request, gql } from 'graphql-request'
import { WebSocketServer } from 'ws';
import { useServer } from 'graphql-ws/lib/use/ws';
import userModel from'../modules/user/model.js';
import PubSub from '../config/redis.js';
import Keyv from "keyv";
import { KeyvAdapter } from "@apollo/utils.keyvadapter";
import { ApolloServerPluginCacheControl } from '@apollo/server/plugin/cacheControl';
import responseCachePlugin from '@apollo/server-plugin-response-cache';
import { ApolloServerPluginCacheControlDisabled } from '@apollo/server/plugin/disabled';
// import jwt from '../helper/jwt.js'

const httpServer = http.createServer(app);
  // app.use(express.static(path.join(path.resolve(), 'dist')));
// // parse application/x-www-form-urlencoded
app.use(cors())
app.use(bodyParser.urlencoded({ extended: false }));
app.set("trust proxy", true);
// // parse application/json
app.use(bodyParser.json());
app.use(graphqlUploadExpress())

const wsServer = new WebSocketServer({
  server: httpServer,
  path: '/gql',
});
const serverCleanup = useServer({ schema }, wsServer);
// console.log(`redis://${process.env.REDIS_PASSWORD}@${process.env.REDIS_HOST}:${process.env.REDIS_PORT}?db=${process.env.REDIS_DB}`);
const server = new ApolloServer({
  schema:schema,
  cache: 'bounded',
  // cache:  new KeyvAdapter(new Keyv(`redis://serova.id:8379`)),
  // introspection:false,
  csrfPrevention: true,
  plugins: [
    ApolloServerPluginDrainHttpServer({ httpServer }),
    {
      async serverWillStart() {
        return {
          async drainServer() {
            await serverCleanup.dispose();
          },
        };
      },
    },
    // ApolloServerPluginLandingPageDisabled()
    // ApolloServerPluginCacheControl({ defaultMaxAge: 100 }),
    // ApolloServerPluginCacheControlDisabled(),
    // responseCachePlugin()
  ],
});
await server.start();
app.use(
  '/gql',
  expressMiddleware(server,
    {
      context: async ({ req }) => { 
        try {
        //  console.log(req);
          let user =null;
          // console.log(req.headers);
          let token = (req.headers.authorization)?req.headers.authorization:'';
      
          if(token){
         
            let dt = token.split(" ");
            if(dt.length>1){
              let data = await jwt.verify(dt[1]);
              // console.log(data);
              if(data){
               user = data
                let dataa = {
                     "id": uuidv4(),
                     "email": user.email,
                     // "action_name": input.amount,
                     // "graphql_schema": input.app_fdTicketId,
                      "graphql_type": req.body.operationName,
                     "graphql_queries": req.body.query,
                     "graphql_variables":req.body.variables
                   }
                   log_model.create(dataa)
              //  console.log(data, 'haha');
              }else{
                let qu = gql`
                query getMe {
                             me {
                               id
                               email
                               firstName
                               middleName
                               lastName
                               dateJoined
                               modified
                               dateJoined
                               lastName
                               lastLogin
                               verified
                               socialAuth {
                                 id
                                 provider
                               }
                               profile {
                                 created
                                 modified
                                 id
                                 gender
                                 picture
                                 dateOfBirth
                                 nationality
                                 timezone
                                 address
                                 inviteCode
                                 company
                                 legacyId
                               }
                             }
                           }`
                 let requestHeaders = {
                   authorization: `Bearer ${dt[1]}`
                 }
                 // console.log(requestHeaders);
                 let h=    await request({
                   url:process.env.SHELIAK_URL,
                   document:qu,
                   requestHeaders,
                 });
            
                 // console.log(h, 'cccc');
                 // user=await jwt.verify(dt[1]);
                 if(h.me){
                   user = h.me
                   let dataa = {
                     "id": uuidv4(),
                     "email": user.email,
                     // "action_name": input.amount,
                     // "graphql_schema": input.app_fdTicketId,
                      "graphql_type": req.body.operationName,
                     "graphql_queries": req.body.query,
                     "graphql_variables":req.body.variables
                   }
                    userModel.update(
                    {last_login:user.lastLogin},
                     { where: { email:user.email } }
                   )
                   log_model.create(dataa)
                   // console.log(user);
                   //     console.log(req.body.query);
                   //    console.log(req.body.variables);
                 }
              }
              // console.log(dt);
            
              
               
              
        
            } 
          }
         
          return {user};
        } catch (error) {
          // console.log("mlebu kene");
      //  console.log(error);
          return {user:null};
        }
      

    }
  }),
);

 app.use('/',router);
 app.use((err, req, res, next)=>{
  res.json({pesan:'error', error: err})
})
export default httpServer;