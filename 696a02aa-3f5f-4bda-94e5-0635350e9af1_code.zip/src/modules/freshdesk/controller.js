
const model = require('./model');
const uuid = require('uuid');
class Fd{
   static async ticketUpdate(req,res){
      // console.log(req.body);
      let input ={};
      input.id=uuid.v4()
      input.json = JSON.stringify(req.body)
      await model.create(input)
      res.json({status:'ok'})
   }
}

module.exports = Fd;