const {DataTypes, ENUM } = require('sequelize');
const koneksi = require('../../config/koneksi.js');

const Ticket = koneksi.define('tickets', {
    // Model attributes are defined here
    id: {
      type: DataTypes.STRING,
        primaryKey: true
      },
    json: {
      type: DataTypes.TEXT
    }
  }, {
    // Other model options go here
    freezeTableName: true,
    paranoid:true,
    deletedAt: 'deleted'
  });
module.exports = Ticket;