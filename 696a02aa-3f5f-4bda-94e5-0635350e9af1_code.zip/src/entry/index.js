
module.exports = require('./entry')